<?php

class Extension_Filter{
	public function __construct(){
		
	}
}