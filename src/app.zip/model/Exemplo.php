<?php

class Model_Exemplo extends Base_Model{
	protected $table = 'tabela_exemplo';
}