<?php

class Controller_Main{
	public function home(){
		response()->view('home');
	}
}