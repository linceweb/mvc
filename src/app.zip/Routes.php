<?php
	
	$app->get('/', ['Controller_Main', 'home']);