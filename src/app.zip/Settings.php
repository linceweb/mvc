<?php

	return [

		'database' => [

			'driver'    => 'mysql',
		    'host'      => 'localhost',
		    'database'  => 'database',
		    'username'  => 'root',
		    'password'  => 'root',
		    'charset'   => 'utf8',
		    'collation' => 'utf8_unicode_ci',
		    'prefix'    => '',

		]

	];